(function(){
	angular
	.module('faiseanrata')
	.constant('appConstants', {
	"apiUrl" : "http://faiseanrata.com:5678/api/"
	//  "apiUrl" : "http://52.76.37.242:4000/api/"
	})
})();